﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','eo',{placeholder:{title:'Atributoj de la rezervita spaco',toolbar:'Krei la rezervitan spacon',text:'Texto de la rezervita spaco',edit:'Modifi la rezervitan spacon',textMissing:'La rezervita spaco devas enteni tekston.'}});
